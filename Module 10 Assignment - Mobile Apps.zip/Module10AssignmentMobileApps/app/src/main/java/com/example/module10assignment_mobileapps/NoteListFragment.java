package com.example.module10assignment_mobileapps;

    public class NoteListFragment extends Fragment
    {
        private NoteListViewModel noteListViewModel;
        private NoteListAdapter noteListAdapter;

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.inflate(R.layout.fragment_note_list, container, false);

            RecyclerView noteRecyclerView = view.findViewById(R.id.noteRecyclerView);
            noteRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
            noteListAdapter = new NoteListAdapter();
            noteRecyclerView.setAdapter(noteListAdapter);

            noteListViewModel = new ViewModelProvider(this).get(NoteListViewModel.class);
            noteListViewModel.getNotesLiveData().observe(getViewLifecycleOwner(), notes -> noteListAdapter.setNotes(notes));

            return view;
        }
    }