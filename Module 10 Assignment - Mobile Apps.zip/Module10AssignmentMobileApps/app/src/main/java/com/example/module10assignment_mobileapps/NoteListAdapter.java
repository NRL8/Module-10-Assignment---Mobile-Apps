package com.example.module10assignment_mobileapps;

    public class NoteListAdapter extends RecyclerView.Adapter<NoteListAdapter.NoteViewHolder>
    {
        private List<Note> notes;

        public void setNotes(List<Note> notes)
        {
            this.notes = notes;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
        {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_note_item, parent, false);
            return new NoteViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull NoteViewHolder holder, int position)
        {
            Note note = notes.get(position);
            holder.noteTextView.setText(note.text);
        }

        @Override
        public int getItemCount() {
            return notes != null ? notes.size() : 0;
        }

        public static class NoteViewHolder extends RecyclerView.ViewHolder
        {
            public TextView noteTextView;

            public NoteViewHolder(@NonNull View itemView) {
                super(itemView);
                noteTextView = itemView.findViewById(R.id.noteTextView);
            }
        }
    }
