package com.example.module10assignment_mobileapps;

    public class CountNotesFragment extends Fragment
    {
        private CountNotesViewModel countNotesViewModel;

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.inflate(R.layout.fragment_count_notes, container, false);

            TextView countTextView = view.findViewById(R.id.countTextView);
            EditText noteEditText = view.findViewById(R.id.noteEditText);
            Button addNoteButton = view.findViewById(R.id.addNoteButton);

            countNotesViewModel = new ViewModelProvider(this).get(CountNotesViewModel.class);
            countNotesViewModel.getNoteCountLiveData().observe(getViewLifecycleOwner(), count -> countTextView.setText(String.valueOf(count)));

            addNoteButton.setOnClickListener(v ->
            {
                String noteText = noteEditText.getText().toString().trim();
                if (!noteText.isEmpty())
                {
                    countNotesViewModel.insertNewNote(noteText);
                    noteEditText.setText("");
                }
            });

            return view;
        }
    }