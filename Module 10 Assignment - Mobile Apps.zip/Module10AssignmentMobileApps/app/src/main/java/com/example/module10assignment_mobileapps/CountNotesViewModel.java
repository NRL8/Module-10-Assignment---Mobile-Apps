package com.example.module10assignment_mobileapps;

    public class CountNotesViewModel extends ViewModel
    {
        private NotesRepository notesRepository;
        private MutableLiveData<Integer> noteCountLiveData = new MutableLiveData<>();

        public CountNotesViewModel()
        {
            notesRepository = ((NotesApplication) getApplication()).getNotesRepository();
            noteCountLiveData.setValue(0);
        }

        public LiveData<Integer> getNoteCountLiveData()
        {
            return noteCountLiveData;
        }

        public void insertNewNote(String noteText)
        {
            Note note = new Note();
            note.text = noteText;
            notesRepository.insert(note);

            noteCountLiveData.setValue(noteCountLiveData.getValue() + 1);
        }
    }