package com.example.module10assignment_mobileapps;

    @Database(entities = {Note.class}, version = 1)
    public abstract class NotesDatabase extends RoomDatabase
    {
        public abstract NoteDao noteDao();

        private static volatile NotesDatabase INSTANCE;

        public static NotesDatabase getInstance(Context context)
        {
            if (INSTANCE == null)
            {
                synchronized (NotesDatabase.class)
                {
                    if (INSTANCE == null)
                    {
                        INSTANCE = Room.databaseBuilder(
                                context.getApplicationContext(),
                                NotesDatabase.class,
                                "notes_database"
                        ).build();
                    }
                }
            }
            return INSTANCE;
        }
    }