package com.example.module10assignment_mobileapps;

    public class NoteListViewModel extends ViewModel
    {
        private NotesRepository notesRepository;
        private LiveData<List<Note>> notesLiveData;

        public NoteListViewModel()
        {
            notesRepository = ((NotesApplication) getApplication()).getNotesRepository();
            notesLiveData = notesRepository.getAllNotes();
        }

        public LiveData<List<Note>> getNotesLiveData()
        {
            return notesLiveData;
        }
    }