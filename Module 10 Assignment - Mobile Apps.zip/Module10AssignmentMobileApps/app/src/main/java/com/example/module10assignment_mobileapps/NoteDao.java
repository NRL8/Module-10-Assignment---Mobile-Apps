package com.example.module10assignment_mobileapps;

    @Dao
    public interface NoteDao
    {
        @Query("SELECT * FROM notes")
        LiveData<List<Note>> getAllNotes();

        @Insert
        void insert(Note note);
    }