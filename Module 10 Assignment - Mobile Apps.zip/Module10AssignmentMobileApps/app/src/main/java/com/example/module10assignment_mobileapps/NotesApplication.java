package com.example.module10assignment_mobileapps;

    public class NotesApplication extends Application
    {
        private NotesRepository notesRepository;

        @Override
        public void onCreate()
        {
            super.onCreate();
            NotesDatabase notesDatabase = NotesDatabase.getInstance(this);
            NoteDao noteDao = notesDatabase.noteDao();
            notesRepository = new NotesRepositoryImpl(noteDao);
        }

        public NotesRepository getNotesRepository()
        {
            return notesRepository;
        }
    }