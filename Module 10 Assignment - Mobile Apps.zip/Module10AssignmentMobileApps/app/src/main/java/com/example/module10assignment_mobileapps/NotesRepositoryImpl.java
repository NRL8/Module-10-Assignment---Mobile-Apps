package com.example.module10assignment_mobileapps;

    public class NotesRepositoryImpl implements NotesRepository
    {
        private NoteDao noteDao;

        public NotesRepositoryImpl(NoteDao noteDao)
        {
            this.noteDao = noteDao;
        }

        @Override
        public LiveData<List<Note>> getAllNotes()
        {
            return noteDao.getAllNotes();
        }

        @Override
        public void insert(Note note)
        {
            new Thread(() -> noteDao.insert(note)).start();
        }
    }