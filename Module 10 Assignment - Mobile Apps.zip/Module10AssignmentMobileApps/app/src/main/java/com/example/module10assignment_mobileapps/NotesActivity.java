package com.example.module10assignment_mobileapps;

    public class NotesActivity extends AppCompatActivity
    {
        @Override
        protected void onCreate(Bundle savedInstanceState)
        {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_notes);
        }
    }