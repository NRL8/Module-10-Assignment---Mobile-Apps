package com.example.module10assignment_mobileapps;

    public interface NotesRepository
    {
        LiveData<List<Note>> getAllNotes();
        void insert(Note note);
    }